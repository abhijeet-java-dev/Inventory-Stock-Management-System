package amart.gui;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import amart.dao.OrderDAO;

public class Pay extends JFrame {
    private String orderId;

    public Pay(String orderId) {
        this.orderId = orderId;
        setTitle("Payment Options");
        setSize(400,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5,1,10,10));
        JLabel lbl = new JLabel("Select Payment Method:",SwingConstants.CENTER);
        lbl.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(lbl);

        JButton cashBtn = new JButton("Cash Payment");
        JButton cardBtn = new JButton("Card Payment");
        JButton qrBtn = new JButton("QR Payment");
        JButton netBtn = new JButton("Net Banking");

        panel.add(cashBtn); panel.add(cardBtn); panel.add(qrBtn); panel.add(netBtn);
        add(panel);

//        cashBtn.addActionListener(e -> processPayment("Cash"));
//        cardBtn.addActionListener(e -> processPayment("Card"));
//        netBtn.addActionListener(e -> processPayment("NetBanking"));
//        qrBtn.addActionListener(e -> {
//            QRPaymentFrame qrFrame = null;
//            try { qrFrame = new QRPaymentFrame(orderId); qrFrame.setVisible(true);}
//            catch(Exception ex){ ex.printStackTrace(); }
//            dispose();
//        });
    }

//    private void processPayment(String method) {
//        try {
//            boolean res = OrderDAO.updatePaymentMethod(orderId, method);
//            if(res) JOptionPane.showMessageDialog(this, method+" Payment Successful!");
//            else JOptionPane.showMessageDialog(this, "Payment Failed!");
//        } catch(SQLException ex) { ex.printStackTrace(); }
//        dispose();
//    }
}

